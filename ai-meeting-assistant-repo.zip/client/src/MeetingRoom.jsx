import React, { useState, useEffect } from "react";
import io from "socket.io-client";
import axios from "axios";

const socket = io("/", { path: "/socket.io" });

export default function MeetingRoom() {
  const [notes, setNotes] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [chunks, setChunks] = useState([]);

  useEffect(() => {
    socket.on("update_notes", setNotes);
    return () => socket.off("update_notes");
  }, []);

  useEffect(() => {
    if (!mediaRecorder) return;
    mediaRecorder.ondataavailable = (e) => setChunks((prev) => [...prev, e.data]);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(chunks, { type: "audio/webm" });
      const formData = new FormData();
      formData.append("audio", blob);

      try {
        const response = await axios.post("/api/transcribe", formData);
        if (response.data.summary) {
          const updatedNotes = notes + "\n\n🧠 Summary:\n" + response.data.summary;
          setNotes(updatedNotes);
          socket.emit("edit_notes", updatedNotes);
          await axios.post("/api/notify-slack", {
            message: `🧠 New Meeting Summary:\n\n${response.data.summary}`
          });
        }
      } catch (err) {
        console.error("Error in transcription or Slack notification:", err);
      }

      setChunks([]);
    };
  }, [mediaRecorder, chunks, notes]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    setMediaRecorder(recorder);
    recorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    mediaRecorder.stop();
    setIsRecording(false);
  };

  const handleChange = (e) => {
    setNotes(e.target.value);
    socket.emit("edit_notes", e.target.value);
  };

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🧠 AI Meeting Assistant</h1>
      <textarea
        value={notes}
        onChange={handleChange}
        className="w-full h-80 p-4 border rounded-md shadow-md"
        placeholder="Start collaborating..."
      ></textarea>
      <div className="mt-4">
        {isRecording ? (
          <button
            onClick={stopRecording}
            className="bg-red-600 text-white px-4 py-2 rounded-md"
          >
            Stop Recording
          </button>
        ) : (
          <button
            onClick={startRecording}
            className="bg-blue-600 text-white px-4 py-2 rounded-md"
          >
            Start Recording
          </button>
        )}
      </div>
    </div>
  );
}