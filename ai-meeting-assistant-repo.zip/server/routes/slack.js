const express = require("express");
const router = express.Router();
const fetch = require("node-fetch");

router.post("/", async (req, res) => {
  const { message } = req.body;
  const webhook = process.env.SLACK_WEBHOOK_URL;
  if (!webhook) return res.status(500).json({ error: "Missing Slack webhook" });

  try {
    await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: message })
    });
    res.json({ ok: true });
  } catch (err) {
    console.error("Slack webhook error:", err);
    res.status(500).json({ error: "Slack error" });
  }
});

module.exports = router;