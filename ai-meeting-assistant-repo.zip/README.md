# 🧠 AI Meeting Assistant

An AI-powered collaborative meeting app with voice transcription, GPT summaries, and Slack integration.

## 🚀 Features
- 🎙️ Audio recording + Whisper transcription
- ✨ GPT-powered live summaries
- 🔁 Real-time note collaboration via Socket.IO
- 📬 Automatic Slack summary delivery

## 📦 Tech Stack
- React + Tailwind
- Node.js + Express
- OpenAI GPT + Whisper
- Slack Webhooks
- Docker + NGINX + HTTPS

## 🛠️ Setup
1. Clone repo
2. Fill `.env` using `.env.example`
3. Run: `docker-compose up --build`
4. Access via: `http://localhost` or your domain

## 🔒 HTTPS Setup
Configure DNS → your VPS IP  
Run Certbot via Docker  
Reload nginx

---

Built to stand out on resumes and impress real hiring teams!